package com.main.service;

import java.util.List;

import com.main.model.Register;

public interface RegisterService {

	void saveRegister(Register register);

	List<Register> fetchData();

}
