package com.main.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.RegisterRepositorys;
import com.main.model.Register;

@Service
@Transactional
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	RegisterRepositorys repo;
	
	
	public void saveRegister(Register register) {
		
		repo.save(register);
	}



	public List<Register> fetchData() {
		
		return repo.findAll();
	}

	
	
	
}
